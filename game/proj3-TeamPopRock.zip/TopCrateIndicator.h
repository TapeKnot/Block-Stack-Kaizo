//#pragma once
//
//#include "dragonfly/ViewObject.h"
//
//class TopCrateIndicator : public df::ViewObject {
//private:
//
//public:
//    GameEnd();
//    int eventHandler(const df::Event* p_e) override;
//    int draw() override;
//};