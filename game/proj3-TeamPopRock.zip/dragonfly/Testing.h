#pragma once

namespace ts {

	const static int TEST_LOG_LEVEL = 1;
}
